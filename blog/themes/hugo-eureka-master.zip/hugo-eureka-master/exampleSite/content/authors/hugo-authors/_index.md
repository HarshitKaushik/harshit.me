---
title: Hugo Authors
role: Example Role
bio: Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos.
organization:
  name: Example Organization
  url: https://example.com/
social:
  - icon: envelope
    iconPack: fas
    url: mailto:example@example.com
  - icon: twitter
    iconPack: fab
    url: https://example.com/
  - icon: github
    iconPack: fab
    url: https://example.com/
---

## Vestibulum vel arcu

Donec interdum justo sed posuere imperdiet. Quisque nec mauris eu erat mattis egestas in vitae nisl. Sed nisl augue, congue sed quam quis, tempor tempus nibh. Pellentesque accumsan in quam a interdum. Morbi iaculis venenatis lacinia. Mauris quis nisl vitae nisi mollis placerat id vel ligula. Integer vitae arcu ac leo iaculis rhoncus id vitae dolor. Fusce quis nisl tincidunt, vulputate dolor quis, mollis massa. Donec congue velit at risus cursus, eu auctor dolor rhoncus. In porta at dolor at eleifend. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Pellentesque vehicula mi at dapibus sodales. Morbi accumsan dictum maximus. In eget leo in purus commodo vestibulum. Duis et velit ex.

Nam turpis ligula, commodo eu nunc eget, rutrum convallis dui. Integer posuere massa nibh, sit amet hendrerit lectus facilisis sed. Pellentesque ut auctor urna. Vestibulum cursus varius enim in ullamcorper. Sed sed risus ac lorem porttitor rhoncus commodo ut nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed eu urna auctor, scelerisque enim nec, eleifend nisl. Vestibulum nec mauris commodo, egestas justo id, consequat leo. Mauris diam justo, sagittis vel posuere a, imperdiet vel sem. Curabitur eget arcu euismod, consectetur arcu non, posuere neque. Integer commodo dolor volutpat, gravida nunc in, tempus mauris. Suspendisse iaculis purus ut vehicula facilisis. Suspendisse vitae diam ipsum. In consequat vitae dui vitae tincidunt.

Nullam eleifend fringilla quam. Sed faucibus efficitur metus at rhoncus. Sed non nunc mollis, cursus ipsum suscipit, blandit mi. Morbi ac interdum massa, non congue ligula. Suspendisse porta condimentum finibus. Donec lobortis eget nisl posuere vehicula. Aenean in mi mollis nisl fermentum lobortis non at lacus. Suspendisse sagittis dolor vitae vehicula gravida. Mauris in dui eu arcu viverra eleifend. Vestibulum nibh sapien, elementum et viverra a, laoreet sit amet felis. Lorem ipsum dolor sit amet, consectetur adipiscing elit.

## Nunc magna est

Donec porta:  
- Aenean aliquam sapien id fermentum hendrerit.
- Nullam quis augue id ante tempor suscipit sodales sed velit.
- Sed at nulla consectetur, sodales nisl sed, luctus velit.
- Morbi ornare purus at porttitor tristique.

Gravida urna in: 
- Maecenas blandit diam at massa hendrerit maximus.
- Sed lacinia purus ac cursus tincidunt.
- Maecenas posuere ante sed elit tempus porttitor.
- Sed vel justo quis diam convallis hendrerit ac non mi. 
