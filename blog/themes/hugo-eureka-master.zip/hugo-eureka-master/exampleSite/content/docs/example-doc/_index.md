---
title: Example Doc
description: This is an example doc layout of Eureka theme
toc: true
authors:
tags:
categories:
series:
date: '2020-10-16'
lastmod: '2020-10-16'
draft: false
---

This is the root of example doc.

## Duis vel leo nec mi convallis sodales

Sed efficitur nibh sed euismod dictum. Donec posuere, nisl a egestas dignissim, risus magna placerat tortor, quis tincidunt ipsum erat at nunc. Cras consectetur ex eget tortor fermentum mattis. Nullam sodales sed purus eget ornare. Vestibulum aliquam cursus odio vitae placerat. Etiam vel pharetra diam. Morbi molestie varius tincidunt. Morbi molestie tortor vitae metus venenatis, ut fermentum nisl luctus. Aenean at condimentum lorem, rhoncus dapibus nibh. Donec et dui consequat ipsum ultrices tristique vitae vitae est.

## Sed efficitur ante a tortor euismod

In ornare ultricies sapien in tincidunt. Integer malesuada tellus sed nibh dictum facilisis non sit amet nibh. Vestibulum sed tincidunt ante, nec tincidunt lectus. Pellentesque id dolor ipsum. Sed efficitur tristique mauris eu tristique. Aliquam nec volutpat dolor. Praesent vitae feugiat nibh. Curabitur mollis placerat sem, ut eleifend mi. Sed sed nisl elit. Pellentesque eget elit nec arcu imperdiet imperdiet. Aliquam dictum arcu ac pharetra rutrum.

### Cras ac diam efficitur

Donec iaculis bibendum suscipit. Ut egestas ligula vel orci posuere scelerisque. Nam vel elementum nibh, congue tempus sapien. Aliquam luctus ante sit amet urna vehicula hendrerit. Morbi at ante nisl. Sed euismod vel dolor in iaculis. Aliquam lacinia lorem sit amet vestibulum finibus. Nulla facilisi. Vivamus lacinia consectetur hendrerit. Integer commodo a nibh nec rhoncus. Nulla non aliquet erat. Cras vel orci a urna malesuada viverra vel quis nisi. Donec pharetra laoreet ante, vulputate volutpat ante consequat eget. Donec efficitur consequat nisi vitae volutpat. Vestibulum volutpat, odio nec sodales cursus, ligula nulla pellentesque erat, ut iaculis magna lorem non purus. Curabitur efficitur tortor et elit sodales, in lobortis risus feugiat.

### Cras hendrerit nibh non pulvinar consectetur

Donec justo diam, auctor et rhoncus a, feugiat in felis. Etiam lectus est, tincidunt iaculis mi et, feugiat rutrum tellus. Ut sit amet tellus vitae nisi faucibus pulvinar non a augue. Etiam auctor porttitor mi, vitae posuere lacus pretium ac. Pellentesque sed ante magna. Proin tempor faucibus risus, vitae tincidunt arcu ultrices egestas. Aenean rutrum purus vel vulputate lobortis. Aenean auctor ipsum quam, eu molestie magna ultricies quis. Phasellus vitae diam erat. Nam at facilisis massa. Nam vulputate nec quam vel iaculis. Maecenas mauris felis, semper vel ultricies eu, interdum condimentum lacus. Mauris quis tincidunt erat, quis efficitur dolor.

## Quisque vehicula tellus eget nunc molestie

Phasellus ligula tortor, sodales ac ipsum vel, lobortis lacinia eros. Maecenas et viverra enim, sit amet bibendum risus. Duis a est pulvinar, suscipit diam id, sagittis lectus. Sed vulputate est sed ipsum faucibus tempus. Morbi non varius nibh. Vestibulum vel tincidunt neque. Vestibulum pellentesque sed metus eu gravida. Donec rhoncus, quam in dictum bibendum, diam libero pretium lacus, vitae suscipit diam neque eget arcu. Pellentesque id hendrerit lorem. Curabitur fermentum purus orci, nec ullamcorper dolor consequat at. Suspendisse lectus dolor, efficitur non mollis eget, suscipit ut nisl. Quisque id ex metus. Sed lobortis venenatis lacinia. Sed at lorem leo.
