---
# Name
title: {{ replace .Name "-" " " | title }}
role:
bio:
avatar:

organization:
  name:
  url:

# Check the available icons on https://fontawesome.com/.
# You can get similar results like this <i class="fab fa-github"></i> after searching.
# Then icon is github and iconPack is fab for this case.
social:
  - icon:
    iconPack:
    url:
---